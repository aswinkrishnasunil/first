from django.contrib import admin
from .models import table

# Register your models here.
admin.site.register(table)