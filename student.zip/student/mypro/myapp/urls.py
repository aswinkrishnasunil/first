from django.urls import path
from .import views

urlpatterns =[
    path ('',views.reg,name="reg"),

    path('login/',views.login,name="login"),

    path('loguser/',views.loguser,name='loguser'),

    path('wel/',views.wel,name="wel"),

    path('view/',views.view ,name='view'),
    path('detail/<str:pk>',views.detail,name="detail"),
    path('update/<str:pk>',views.update,name="update"),
    path('delete/<str:pk>',views.delete,name="delete"),
]